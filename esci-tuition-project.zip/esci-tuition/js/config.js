// Public frontend configuration only. Never put a service_role key here.
export const CONFIG = {
  SUPABASE_URL: 'https://YOUR_PROJECT_ID.supabase.co',
  SUPABASE_ANON_KEY: 'YOUR_SUPABASE_ANON_PUBLIC_KEY',
  BRAND_NAME: 'ESci.lk',
  TEACHER_NAME: 'Kavisha Herath',
  CONTACT_PHONE: '',
  CONTACT_EMAIL: '',
  SOCIAL: { youtube: '#', facebook: '#', whatsapp_channel: '#', whatsapp_chat: '#' }
};
