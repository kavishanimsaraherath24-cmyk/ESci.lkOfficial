# ESci.lk — Tuition Management Website

Vanilla HTML5, CSS3 and ES modules with Supabase (Auth, Postgres, Storage). The public site is `index.html`; student and admin portals are under `pages/`.

## Folder structure

```text
esci-tuition/
├── index.html
├── css/ style.css, panel.css
├── js/ app.js, config.js, supabase.js, dashboard.js, admin.js, reset.js
├── pages/ dashboard.html, admin.html, reset-password.html, 404.html
├── sql/ schema.sql
└── .env.example
```

## 1. Supabase setup

1. Create a project at https://supabase.com/.
2. Open **SQL Editor**, paste and run `sql/schema.sql`.
3. In **Project Settings → API**, copy the Project URL and anon/public key into `js/config.js`.
4. In **Authentication → URL Configuration**, set the Site URL to your local/deployed origin and add redirect URLs for `pages/reset-password.html`.
5. Enable email confirmations if desired. Registration metadata is processed by a database trigger, so the student and pending class-enrolment records are created even when email confirmation is enabled. The student must verify the email and sign in before using protected areas.
6. The SQL creates private `payment-receipts` and `learning-resources` buckets and storage policies.

Only the anon/public key belongs in browser code. Never use the service-role key in this project.

## 2. Create the first administrator

1. Register a normal account through the site and verify its email.
2. In Supabase **Authentication → Users**, copy that user's UUID.
3. In SQL Editor run:

```sql
insert into public.admin_users(user_id) values ('PASTE-AUTH-USER-UUID-HERE');
update public.profiles set role='admin' where id='PASTE-AUTH-USER-UUID-HERE';
```

Admin access is checked against `admin_users` on the server through RLS. Do not expose a public admin sign-up form.

## 3. Run locally

ES modules require a local web server (not `file://`). In VS Code install/use Live Server and open `index.html`, or run:

```bash
python -m http.server 5500
```

Then open `http://localhost:5500`. Add this origin to Supabase Auth redirect URLs.

## 4. Configure brand details

Edit `js/config.js` for contact phone/email and social links. Replace the teacher photo placeholder and add the official teacher photo/logo in `assets/` when available. Set real class fees, schedule and meeting links from the admin workflow / Supabase table. Use HTTPS links only.

## 5. Deploy

Upload the folder to any static host that serves HTML/CSS/JS (Netlify, Cloudflare Pages, GitHub Pages, or your own HTTPS hosting). Set the production domain as the Supabase Site URL and add reset redirect URLs. Configure a custom 404 route to `pages/404.html` where supported.

## Important scope / remaining configuration

This is a working starter implementation, not a fully audited production SaaS. Supabase project credentials, domain, email templates, real bank details, teacher image, social URLs and YouTube channel must be configured by the site owner. Admin panel currently supports student status changes, payment verification, class creation, announcements, CSV export and message viewing. Class editing/deletion, resource upload UI, complete settings editor, configurable bank instructions, YouTube API latest-video integration, richer timetable editor and deletion confirmation workflow remain to be implemented. A student registration is created as `pending`; admin must activate it. Payment approval is always manual.

Before public launch, test the flows with separate student/admin accounts and review RLS/storage policies in Supabase. Consider moving any complex admin operations into trusted Edge Functions and add rate limiting, CAPTCHA, audit logs, backups, privacy/terms pages and email notifications. Do not collect more personal data than necessary. Since many students are minors, obtain and retain valid guardian consent and publish a locally compliant privacy notice.

## Security notes

- Auth passwords are handled by Supabase Auth; this app never stores plaintext passwords.
- RLS is enabled on all application tables. Students can read their own records; admins are allow-listed in `admin_users`.
- Receipts and learning resources are stored in private buckets and accessed through short-lived signed URLs.
- Public frontend code contains only the anon key. The service-role key must remain server-side.
- Verify RLS policies in a non-production test project before accepting real student data.
