-- ESci.lk Supabase schema. Run in Supabase SQL Editor as project owner.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now()
);
create table if not exists public.students (
  id uuid primary key references auth.users(id) on delete cascade,
  student_code text unique,
  full_name text not null,
  date_of_birth date,
  gender text,
  student_phone text not null,
  guardian_name text not null,
  guardian_phone text not null,
  whatsapp_number text,
  email text not null,
  house_number text,
  street text,
  city text not null,
  district text not null,
  postal_code text,
  school_name text not null,
  grade int not null check (grade between 6 and 11),
  student_type text not null check (student_type in ('New Student','Existing Student')),
  status text not null default 'pending' check (status in ('pending','active','suspended')),
  guardian_consent boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.classes (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  grade int not null check (grade between 6 and 11),
  description text,
  schedule text,
  monthly_fee numeric(10,2) not null default 0,
  class_link text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.student_classes (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(student_id,class_id)
);
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  class_id uuid not null references public.classes(id),
  payment_month text not null,
  amount numeric(10,2) not null check (amount > 0),
  payment_date date not null,
  transaction_reference text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  rejection_reason text,
  verified_at timestamptz,
  verified_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create table if not exists public.payment_receipts (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null references public.payments(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  file_path text not null,
  created_at timestamptz not null default now()
);
create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text,
  is_published boolean not null default false,
  published_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists public.learning_resources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  grade int not null check (grade between 6 and 11),
  file_path text not null,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists public.contact_messages (
  id uuid primary key default gen_random_uuid(),
  student_name text not null,
  phone text not null,
  subject text not null,
  message text not null,
  created_at timestamptz not null default now()
);
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table if not exists public.site_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- Generate a readable student code after student row creation.
create or replace function public.assign_student_code() returns trigger language plpgsql as $$
begin
  if new.student_code is null then
    new.student_code := 'ES' || to_char(now(),'YY') || '-' || upper(substr(replace(new.id::text,'-',''),1,8));
  end if;
  return new;
end; $$;
drop trigger if exists trg_student_code on public.students;
create trigger trg_student_code before insert on public.students for each row execute function public.assign_student_code();

-- Helper functions use SECURITY DEFINER to avoid recursive RLS checks. Keep search_path locked.
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.admin_users where user_id=auth.uid());
$$;
create or replace function public.is_active_student() returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.students where id=auth.uid() and status='active');
$$;

-- Profile auto-creation. The student row is inserted by the registration frontend after signup.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,full_name,role) values(new.id,coalesce(new.raw_user_meta_data->>'full_name','Student'),'student') on conflict(id) do nothing;
  if new.raw_user_meta_data ? 'student_registration' then
    insert into public.students(id,full_name,date_of_birth,gender,student_phone,guardian_name,guardian_phone,whatsapp_number,email,house_number,street,city,district,postal_code,school_name,grade,student_type,status,guardian_consent)
    values(new.id,coalesce(new.raw_user_meta_data->>'full_name','Student'),
      nullif(new.raw_user_meta_data->'student_registration'->>'date_of_birth','')::date,
      nullif(new.raw_user_meta_data->'student_registration'->>'gender',''),
      new.raw_user_meta_data->'student_registration'->>'student_phone',
      new.raw_user_meta_data->'student_registration'->>'guardian_name',
      new.raw_user_meta_data->'student_registration'->>'guardian_phone',
      nullif(new.raw_user_meta_data->'student_registration'->>'whatsapp_number',''),new.email,
      nullif(new.raw_user_meta_data->'student_registration'->>'house_number',''),
      nullif(new.raw_user_meta_data->'student_registration'->>'street',''),
      new.raw_user_meta_data->'student_registration'->>'city',
      new.raw_user_meta_data->'student_registration'->>'district',
      nullif(new.raw_user_meta_data->'student_registration'->>'postal_code',''),
      new.raw_user_meta_data->'student_registration'->>'school_name',
      (new.raw_user_meta_data->'student_registration'->>'grade')::int,
      new.raw_user_meta_data->'student_registration'->>'student_type','pending',
      coalesce((new.raw_user_meta_data->'student_registration'->>'guardian_consent')::boolean,false));
    insert into public.student_classes(student_id,class_id)
    values(new.id,(new.raw_user_meta_data->'student_registration'->>'class_id')::uuid);
  end if;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.students enable row level security;
alter table public.classes enable row level security;
alter table public.student_classes enable row level security;
alter table public.payments enable row level security;
alter table public.payment_receipts enable row level security;
alter table public.announcements enable row level security;
alter table public.learning_resources enable row level security;
alter table public.contact_messages enable row level security;
alter table public.admin_users enable row level security;
alter table public.site_settings enable row level security;

-- Profiles: users see their own profile; admins can manage all.
create policy "profile own or admin read" on public.profiles for select using (id=auth.uid() or public.is_admin());
create policy "profile own update" on public.profiles for update using (id=auth.uid() and role='student') with check (id=auth.uid() and role='student');
create policy "admin profile manage" on public.profiles for all using (public.is_admin()) with check (public.is_admin());

-- Students: new student can insert their own pending record only; admins manage; owner can read own record.
create policy "student self insert pending" on public.students for insert with check (id=auth.uid() and status='pending' and guardian_consent=true);
create policy "student own read" on public.students for select using (id=auth.uid() or public.is_admin());
create policy "admin student manage" on public.students for all using (public.is_admin()) with check (public.is_admin());

-- Public class catalogue, admin write.
create policy "active classes public read" on public.classes for select using (is_active=true or public.is_admin());
create policy "admin classes manage" on public.classes for all using (public.is_admin()) with check (public.is_admin());
create policy "student own class enrollment read" on public.student_classes for select using (student_id=auth.uid() or public.is_admin());
create policy "student enroll self" on public.student_classes for insert with check (student_id=auth.uid() and exists(select 1 from public.students s where s.id=auth.uid() and s.status='pending'));
create policy "admin enrollment manage" on public.student_classes for all using (public.is_admin()) with check (public.is_admin());

-- Payment records: student sees own, can submit own pending record; admin alone verifies.
create policy "payment own read" on public.payments for select using (student_id=auth.uid() or public.is_admin());
create policy "student submit pending payment" on public.payments for insert with check (student_id=auth.uid() and status='pending' and public.is_active_student());
create policy "admin payment manage" on public.payments for all using (public.is_admin()) with check (public.is_admin());
create policy "receipt own read" on public.payment_receipts for select using (student_id=auth.uid() or public.is_admin());
create policy "receipt own insert" on public.payment_receipts for insert with check (student_id=auth.uid() and public.is_active_student() and exists(select 1 from public.payments p where p.id=payment_id and p.student_id=auth.uid()));
create policy "admin receipt manage" on public.payment_receipts for all using (public.is_admin()) with check (public.is_admin());

create policy "published announcements read" on public.announcements for select using (is_published=true or public.is_admin());
create policy "admin announcements manage" on public.announcements for all using (public.is_admin()) with check (public.is_admin());
create policy "active student resources read" on public.learning_resources for select using ((is_published=true and public.is_active_student() and exists(select 1 from public.students s where s.id=auth.uid() and s.grade=learning_resources.grade)) or public.is_admin());
create policy "admin resources manage" on public.learning_resources for all using (public.is_admin()) with check (public.is_admin());
create policy "anyone submit contact message" on public.contact_messages for insert with check (true);
create policy "admin contact read manage" on public.contact_messages for all using (public.is_admin()) with check (public.is_admin());
create policy "admin users read self or admin" on public.admin_users for select using (user_id=auth.uid() or public.is_admin());
create policy "site settings public read" on public.site_settings for select using (true);
create policy "admin site settings manage" on public.site_settings for all using (public.is_admin()) with check (public.is_admin());

-- Storage buckets: private receipts/resources. Create bucket policies in Storage section below.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values
 ('payment-receipts','payment-receipts',false,5242880,array['image/jpeg','image/png','application/pdf']),
 ('learning-resources','learning-resources',false,20971520,array['application/pdf'])
on conflict(id) do nothing;

create policy "student upload own receipt folder" on storage.objects for insert to authenticated with check (bucket_id='payment-receipts' and (storage.foldername(name))[1]=auth.uid()::text and public.is_active_student());
create policy "student read own receipts admin all" on storage.objects for select to authenticated using (bucket_id='payment-receipts' and ((storage.foldername(name))[1]=auth.uid()::text or public.is_admin()));
create policy "admin upload resources" on storage.objects for insert to authenticated with check (bucket_id='learning-resources' and public.is_admin());
create policy "active student read own grade resources" on storage.objects for select to authenticated using (bucket_id='learning-resources' and (public.is_admin() or (public.is_active_student() and (storage.foldername(name))[1]=(select s.grade::text from public.students s where s.id=auth.uid()))));
create policy "admin update delete storage" on storage.objects for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Seed class rows (optional starter data).
insert into public.classes(name,grade,description,schedule,monthly_fee,is_active) values
('Grade 6 Science',6,'Science foundations','To be announced',0,true),('Grade 7 Science',7,'Explore science','To be announced',0,true),('Grade 8 Science',8,'Build scientific understanding','To be announced',0,true),('Grade 9 Science',9,'Concepts and practice','To be announced',0,true),('Grade 10 Science',10,'O/L science foundation','To be announced',0,true),('Grade 11 Science',11,'O/L science preparation','To be announced',0,true)
on conflict do nothing;
